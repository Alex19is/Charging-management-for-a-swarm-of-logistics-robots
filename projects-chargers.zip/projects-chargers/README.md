# Charging-management-in-a-robotic-warehouse
Управление роботами для развоза товаров на складе, внедрение зарядных устройств
